import sys
import Router.Logger as Logger
import KSR as KSR
import logging
import grpc

def dumpObj(obj):
    for attr in dir(obj):
        # KSR.info("obj.%s = %s\n" % (attr, getattr(obj, attr)))
        Logger.LM_INFO("obj.%s = %s\n" % (attr, getattr(obj, attr)))

# Global function to instantiate a Kamailio class object
# -- executed when Kamailio app_python module is initialized
def mod_init():
    KSR.info("===== from Python mod init\n")
    return kamailio()


    
in_conference=list()
in_session=list()


# Kamailio class definition
class kamailio:

    def __init__(self):
        KSR.info('===== kamailio.__init__\n')


    # Executed when Kamailio child processes are initialized
    def child_init(self, rank):
         
        KSR.info('===== kamailio.child_init(%d)\n' % rank)
        return 0

    # SIP request routing
    # -- equivalent of request_route{}
    def ksr_request_route(self, msg):

        
        # Verificar se o domínio é válido
        if not KSR.pv.get("$fu").endswith("@acme.pt"):
            KSR.info(f"Negado: {KSR.pv.get('$fu')}")
            KSR.sl.send_reply(403, "Forbidden")
            return 1

        # Verificação do método SIP
        if msg.Method == "REGISTER":
            KSR.info("Processando registo de funcionário_...\n")
            KSR.registrar.save("location", 0)  
            return 1
        
        
        if (msg.Method == "INVITE"):
            global in_conference
            global in_session
            
            if KSR.pv.get("$tu") == "sip:conferencia@acme.pt":
                KSR.pv.sets("$ru","sip:inconference@127.0.0.1:5080")
                in_conference.append(KSR.pv.get("$fu"))
                print(f"Halo + {str(in_conference)}")
                status_code = KSR.pv.get("$fu")
                KSR.info(f"Status da resposta_Entrei aqui cralho: {status_code}\n")

                KSR.rr.record_route()
                KSR.tm.t_relay()
                return 1
            

          #  if(KSR.pv.get("$tu") in in_session):
           #     KSR.info("ENtrei aqui bora")
            #    KSR.pv.sets("$ru", "sip:busyann@127.0.0.1:5090")
             #   KSR.rr.record_route()
              #  KSR.tm.t_relay()
               # return 1

            
            
         
                
                
            if KSR.registrar.lookup("location") == 1:
                if(KSR.pv.get("$to") in in_conference ):
                   KSR.pv.sets("$ru","sip:inconference@127.0.0.1:5080")
                   in_conference.append("$fu")
                   in_conference = list(set(in_conference))
                   print(f"Halo6 + {str(in_conference)}")
                   KSR.info("Entrei aqui juro")
                   KSR.rr.record_route()
                   KSR.tm.t_relay()
                   return 1
                
                if(KSR.pv.get("$tu") in in_session):
                    KSR.info("ENtrei aqui bora")
                    KSR.pv.sets("$ru", "sip:busyann@127.0.0.1:5090")
                    KSR.rr.record_route()
                    KSR.tm.t_relay()
                    return 1

                KSR.info("Passando a chamada")
                KSR.rr.record_route()
                KSR.tm.t_relay()
                return 1
            else:
                KSR.info("Destino não encontrado")
                KSR.sl.send_reply(404, "User not found")  
                return 1            

        if msg.Method == "ACK":
            KSR.info("ACK R-URI:" + KSR.pv.get("$ru") + "\n")      
            KSR.rr.loose_route()

            KSR.tm.t_relay()
            return 1



        if msg.Method == "BYE":
            print("Estás ocupada")
            KSR.info("From" + KSR.pv.get("$fu"))
            KSR.info("TO" + KSR.pv.get("$tu"))

            if(KSR.pv.get("$fu") in in_conference):
                in_conference.remove(KSR.pv.get("$fu"))
                KSR.info("Removi do array conferencia")
                in_conference = list(set(in_conference))

                print(f"Halo5 + {str(in_conference)}")

                return 1
            
            if(KSR.pv.get("$fu") in in_session):
                 in_session.remove(KSR.pv.get("$fu"))
                 in_session.remove(KSR.pv.get("$tu"))
                 in_session = list(set(in_session))
                 KSR.info("Removi do array chamada")
                 print(f"Halo4 + {str(in_session)}")
                 return 1
                
            KSR.rr.loose_route()

            KSR.tm.t_relay()
            return 1;    
        
    def ksr_reply_route(self, msg):
        global in_session
        global in_conference
        KSR.info("===== Resposta SIP - de Kamailio Python\n")
        
        # Captura o código de status da resposta SIP
      #  status_code = KSR.pv.get("$rs")
       # KSR.info(f"Status da resposta_este: {status_code}\n")

        # Verifica se a resposta SIP foi "486 Busy Here"
        

        # Se a resposta for qualquer outro código, apenas continue
      #  KSR.tm.t_relay()
        return 1

    def ksr_onsend_route(self, msg):
        KSR.info("Trying to connect to: %s" % KSR.pv.get("$to"))
        global in_session
        global in_conference
        if(KSR.pv.get("$to") == "sip:inconference@127.0.0.1:5080"):
            print("Serei eu?")
            in_conference.append("$fu")
            return 1
        elif (KSR.pv.get("$to") == "sip:busyann@127.0.0.1:5090") :
            return 1
        else:
            in_session.append(KSR.pv.get("$fu"))
            in_session.append(KSR.pv.get("$tu"))
            in_session = list(set(in_session))
            print(f"Halo3 + {str(in_session)}")
            return 1

        
       # KSR.info("===== onsend route - from kamailio python script\n")
       # KSR.info("      %s\n" % (msg.Type))
        return 1


   
         
